Описание полей в датасете про базу домов price_housebase.tsv:
**city_quadkey** - полигон, его координаты можно его узнать из скрипта quadkey.py
**building_id** - id дома
**unified_address** - адрес дома
**building_series_id** - id серии дома
**beauty_cnt** - количество салонов красоты в этом районе city_quadkey	
**shopping_cnt** - количество магазинов в этом районе city_quadkey	 
**cafe_restaurant_eating_out_cnt** - количество точек общественного питания в этом районе city_quadkey	
**entertainment_cnt** - количество организаций в сфере развлечений в этом районе city_quadkey
**sport_cnt** - количество спортивных организаций в этом районе city_quadkey
**chain_cnt** - количество сетевых организаций в этом районе city_quadkey
**groceries_and_everyday_items_cnt** - количество продуктовых магазинов в этом районе city_quadkey	
**art_cnt** - количество организаций в сфере искусства (музеи, галереи и т.п.) в этом районе city_quadkey
**healthcare_cnt** - количество организаций в сфере здравоохранения в этом районе city_quadkey	
**flats_count** - количество квартир в доме	
**laundry_and_repair_services_cnt** - количество прачечных и ремонтных мастерских в этом районе city_quadkey	
**latitude, longitude** - координаты дома
**expect_demolition** - дом входит в программу реновации и ожидает сноса
**ceiling_height** - высота потолков в доме	
**has_elevator** - наличие лифта в доме	
**build_year** - год постройки дома